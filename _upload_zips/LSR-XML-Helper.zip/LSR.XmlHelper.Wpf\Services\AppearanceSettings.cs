﻿using System;

namespace LSR.XmlHelper.Wpf.Services
{
    public sealed class AppearanceSettings
    {
        public AppearanceProfileSettings Dark { get; set; } = AppearanceProfileSettings.CreateDarkDefaults();
        public AppearanceProfileSettings Light { get; set; } = AppearanceProfileSettings.CreateLightDefaults();

        public AppearanceProfileSettings GetActiveProfile(bool isDarkMode) => isDarkMode ? Dark : Light;
    }

    public sealed class AppearanceProfileSettings
    {
        public string UiFontFamily { get; set; } = "Segoe UI";
        public double UiFontSize { get; set; } = 12;
        public bool UiFontBold { get; set; }
        public bool UiFontItalic { get; set; }

        public string EditorFontFamily { get; set; } = "Consolas";
        public double EditorFontSize { get; set; } = 13;
        public bool EditorFontBold { get; set; }
        public bool EditorFontItalic { get; set; }

        public string Text { get; set; } = "#FFD4D4D4";
        public string Background { get; set; } = "#FF1E1E1E";

        public string EditorText { get; set; } = "#FFD4D4D4";
        public string EditorBackground { get; set; } = "#FF1E1E1E";

        public string MenuBackground { get; set; } = "#FF1E1E1E";
        public string MenuText { get; set; } = "#FFD4D4D4";

        public string TreeText { get; set; } = "#FFD4D4D4";
        public string TreeBackground { get; set; } = "#FF1E1E1E";
        public string TreeItemHoverBackground { get; set; } = "#FF252525";
        public string TreeItemSelectedBackground { get; set; } = "#FF2F2F2F";

        private string? _rawTreeText;
        private string? _rawTreeBackground;
        private string? _rawTreeItemHoverBackground;
        private string? _rawTreeItemSelectedBackground;

        private string? _friendlyTreeText;
        private string? _friendlyTreeBackground;
        private string? _friendlyTreeItemHoverBackground;
        private string? _friendlyTreeItemSelectedBackground;

        public string RawTreeText
        {
            get => string.IsNullOrWhiteSpace(_rawTreeText) ? TreeText : _rawTreeText;
            set => _rawTreeText = value;
        }

        public string RawTreeBackground
        {
            get => string.IsNullOrWhiteSpace(_rawTreeBackground) ? TreeBackground : _rawTreeBackground;
            set => _rawTreeBackground = value;
        }

        public string RawTreeItemHoverBackground
        {
            get => string.IsNullOrWhiteSpace(_rawTreeItemHoverBackground) ? TreeItemHoverBackground : _rawTreeItemHoverBackground;
            set => _rawTreeItemHoverBackground = value;
        }

        public string RawTreeItemSelectedBackground
        {
            get => string.IsNullOrWhiteSpace(_rawTreeItemSelectedBackground) ? TreeItemSelectedBackground : _rawTreeItemSelectedBackground;
            set => _rawTreeItemSelectedBackground = value;
        }

        public string FriendlyTreeText
        {
            get => string.IsNullOrWhiteSpace(_friendlyTreeText) ? TreeText : _friendlyTreeText;
            set => _friendlyTreeText = value;
        }

        public string FriendlyTreeBackground
        {
            get => string.IsNullOrWhiteSpace(_friendlyTreeBackground) ? TreeBackground : _friendlyTreeBackground;
            set => _friendlyTreeBackground = value;
        }

        public string FriendlyTreeItemHoverBackground
        {
            get => string.IsNullOrWhiteSpace(_friendlyTreeItemHoverBackground) ? TreeItemHoverBackground : _friendlyTreeItemHoverBackground;
            set => _friendlyTreeItemHoverBackground = value;
        }

        public string FriendlyTreeItemSelectedBackground
        {
            get => string.IsNullOrWhiteSpace(_friendlyTreeItemSelectedBackground) ? TreeItemSelectedBackground : _friendlyTreeItemSelectedBackground;
            set => _friendlyTreeItemSelectedBackground = value;
        }

        public string GridText { get; set; } = "#FFD4D4D4";
        public string GridBackground { get; set; } = "#FF1E1E1E";
        public string GridBorder { get; set; } = "#FF555555";

        public string GridHeaderBackground { get; set; } = "#FF1E1E1E";
        public string GridHeaderText { get; set; } = "#FFD4D4D4";

        public string GridRowHoverBackground { get; set; } = "#FF252525";
        public string GridRowSelectedBackground { get; set; } = "#FF2F2F2F";

        public string GridCellSelectedBackground { get; set; } = "#FF2F2F2F";
        public string GridCellSelectedText { get; set; } = "#FFFFFFFF";

        public string FieldColumnText { get; set; } = "#FFD4D4D4";
        public string ValueColumnText { get; set; } = "#FFD4D4D4";
        public string HeaderText { get; set; } = "#FFD4D4D4";

        public static AppearanceProfileSettings CreateDarkDefaults()
        {
            return new AppearanceProfileSettings
            {
                UiFontFamily = "Segoe UI",
                UiFontSize = 12,

                EditorFontFamily = "Consolas",
                EditorFontSize = 13,

                Text = "#FFD4D4D4",
                Background = "#FF1E1E1E",

                EditorText = "#FFD4D4D4",
                EditorBackground = "#FF1E1E1E",

                MenuBackground = "#FF1E1E1E",
                MenuText = "#FFD4D4D4",

                TreeText = "#FFD4D4D4",
                TreeBackground = "#FF1E1E1E",
                TreeItemHoverBackground = "#FF252525",
                TreeItemSelectedBackground = "#FF2F2F2F",

                GridText = "#FFD4D4D4",
                GridBackground = "#FF1E1E1E",
                GridBorder = "#FF555555",
                GridHeaderBackground = "#FF1E1E1E",
                GridHeaderText = "#FFD4D4D4",

                GridRowHoverBackground = "#FF252525",
                GridRowSelectedBackground = "#FF2F2F2F",

                GridCellSelectedBackground = "#FF2F2F2F",
                GridCellSelectedText = "#FFFFFFFF",

                FieldColumnText = "#FFD4D4D4",
                ValueColumnText = "#FFD4D4D4",
                HeaderText = "#FFD4D4D4"
            };
        }

        public static AppearanceProfileSettings CreateLightDefaults()
        {
            return new AppearanceProfileSettings
            {
                UiFontFamily = "Segoe UI",
                UiFontSize = 12,

                EditorFontFamily = "Consolas",
                EditorFontSize = 13,

                Text = "#FF000000",
                Background = "#FFFFFFFF",

                EditorText = "#FF000000",
                EditorBackground = "#FFFFFFFF",

                MenuBackground = "#FFF5F5F5",
                MenuText = "#FF000000",

                TreeText = "#FF000000",
                TreeBackground = "#FFFFFFFF",
                TreeItemHoverBackground = "#FFEAEAEA",
                TreeItemSelectedBackground = "#FFCCE4FF",

                GridText = "#FF000000",
                GridBackground = "#FFFFFFFF",
                GridBorder = "#FF555555",
                GridHeaderBackground = "#FFF5F5F5",
                GridHeaderText = "#FF000000",

                GridRowHoverBackground = "#FFEAEAEA",
                GridRowSelectedBackground = "#FFCCE4FF",

                GridCellSelectedBackground = "#FFCCE4FF",
                GridCellSelectedText = "#FF000000",

                FieldColumnText = "#FF000000",
                ValueColumnText = "#FF000000",
                HeaderText = "#FF000000"
            };
        }
    }
}
