﻿using System.Windows;

namespace LSR.XmlHelper.Wpf
{
    public partial class App : System.Windows.Application
    {
    }
}
