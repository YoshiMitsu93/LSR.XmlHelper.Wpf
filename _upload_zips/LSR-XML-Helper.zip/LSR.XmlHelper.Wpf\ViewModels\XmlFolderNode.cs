﻿namespace LSR.XmlHelper.Wpf.ViewModels
{
    public sealed class XmlFolderNode : XmlExplorerNode
    {
        public XmlFolderNode(string name) : base(name)
        {
        }
    }
}
