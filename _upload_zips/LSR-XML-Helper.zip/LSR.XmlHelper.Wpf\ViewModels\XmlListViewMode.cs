﻿namespace LSR.XmlHelper.Wpf.ViewModels
{
    public enum XmlListViewMode
    {
        Flat = 0,
        Folders = 1
    }
}